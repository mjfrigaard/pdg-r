# Revdeps

## New problems (1)

|package                              |version |error  |warning |note |
|:------------------------------------|:-------|:------|:-------|:----|
|[duawranglr](problems.md#duawranglr) |0.6.5   |__+1__ |        |1    |

